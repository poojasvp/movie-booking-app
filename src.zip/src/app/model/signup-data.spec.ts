import { SignupData } from './signup-data';

describe('SignupData', () => {
  it('should create an instance', () => {
    expect(new SignupData()).toBeTruthy();
  });
});
