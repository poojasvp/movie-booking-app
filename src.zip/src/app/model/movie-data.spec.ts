import { MovieData } from './movie-data';

describe('MovieData', () => {
  it('should create an instance', () => {
    expect(new MovieData()).toBeTruthy();
  });
});
