export class AddmovieData {
    movieName:string|any;
    theaterName: string|any;
    totalTickets: number|any;
    ticketStatus: string|any;
}
