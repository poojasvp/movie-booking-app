import { AddmovieData } from './addmovie-data';

describe('AddmovieData', () => {
  it('should create an instance', () => {
    expect(new AddmovieData()).toBeTruthy();
  });
});
