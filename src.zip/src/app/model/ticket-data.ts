export class TicketData {
    transactionId!: string;
    numberOfTickets!: number;
    seatNumbers!: string[];
    movieName!: string;
    theaterName!: string;
    userId!: string;
}
