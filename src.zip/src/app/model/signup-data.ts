export class SignupData {
  username: string | any;
  email: string | any;
  password: string | any;
  securityQuestion: string | any;
  securityAnswer: string | any;
}
